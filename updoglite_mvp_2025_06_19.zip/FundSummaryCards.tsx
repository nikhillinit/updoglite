// FundSummaryCards.tsx
// Final version from 2025-06-19 MVP session

